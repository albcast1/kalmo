import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

type Language = 'es' | 'en';

interface LanguageState {
  language: Language;
  setLanguage: (language: Language) => void;
}

export const useLanguageStore = create<LanguageState>()(
  persist(
    (set) => ({
      language: 'es', // Spanish is the default
      setLanguage: (language) => set({ language }),
    }),
    {
      name: 'kalmo-language',
      storage: createJSONStorage(() => localStorage),
    }
  )
);
