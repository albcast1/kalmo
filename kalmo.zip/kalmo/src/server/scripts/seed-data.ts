import { db } from "~/server/db";

export async function seedData() {
  // Check if data already exists
  const existingUsers = await db.user.count();
  if (existingUsers > 0) {
    console.log("Database already seeded, skipping...");
    return;
  }

  console.log("Seeding database with sample data...");

  // Create sample users
  const user1 = await db.user.create({
    data: {
      email: "john.doe@example.com",
      name: "John Doe",
    },
  });

  const user2 = await db.user.create({
    data: {
      email: "mary.smith@example.com",
      name: "Mary Smith",
    },
  });

  // Create sample cameras
  const camera1 = await db.camera.create({
    data: {
      name: "Living Room Camera",
      location: "Living Room, Ground Floor",
      status: "active",
      userId: user1.id,
    },
  });

  const camera2 = await db.camera.create({
    data: {
      name: "Bedroom Camera",
      location: "Master Bedroom, Second Floor",
      status: "active",
      userId: user1.id,
    },
  });

  const camera3 = await db.camera.create({
    data: {
      name: "Kitchen Camera",
      location: "Kitchen Area",
      status: "active",
      userId: user2.id,
    },
  });

  // Create sample alerts
  await db.alert.createMany({
    data: [
      {
        type: "fall",
        severity: "critical",
        description: "Possible fall detected in living room area",
        cameraId: camera1.id,
        resolved: false,
        imageUrl: "https://images.unsplash.com/photo-1581579438747-1dc8d17bbce4?w=800&q=80",
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      },
      {
        type: "motion",
        severity: "low",
        description: "Regular movement detected",
        cameraId: camera1.id,
        resolved: true,
        createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5 hours ago
      },
      {
        type: "inactivity",
        severity: "medium",
        description: "No movement detected for 3 hours",
        cameraId: camera2.id,
        resolved: false,
        imageUrl: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800&q=80",
        createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
      },
      {
        type: "fall",
        severity: "high",
        description: "Fall detected near bed area",
        cameraId: camera2.id,
        resolved: true,
        imageUrl: "https://images.unsplash.com/photo-1559329007-40df8a9345d8?w=800&q=80",
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      },
      {
        type: "motion",
        severity: "low",
        description: "Normal activity in kitchen",
        cameraId: camera3.id,
        resolved: true,
        createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
      },
    ],
  });

  console.log("Database seeded successfully!");
}
