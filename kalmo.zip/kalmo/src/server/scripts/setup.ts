import { seedData } from "~/server/scripts/seed-data";
import { minioClient } from "~/server/minio";

async function setupMinIO() {
  const bucketName = "public";
  
  // Create bucket if it doesn't exist
  const bucketExists = await minioClient.bucketExists(bucketName);
  if (!bucketExists) {
    await minioClient.makeBucket(bucketName);
    console.log(`Created bucket: ${bucketName}`);
    
    // Set bucket policy to allow public read access
    const policy = {
      Version: "2012-10-17",
      Statement: [
        {
          Effect: "Allow",
          Principal: { AWS: ["*"] },
          Action: ["s3:GetObject"],
          Resource: [`arn:aws:s3:::${bucketName}/*`],
        },
      ],
    };
    await minioClient.setBucketPolicy(bucketName, JSON.stringify(policy));
    console.log(`Set public read policy for bucket: ${bucketName}`);
  }
  
  // Check if video already exists
  try {
    await minioClient.statObject(bucketName, "hero-video.mp4");
    console.log("Hero video already exists in MinIO, skipping download...");
    return;
  } catch (error) {
    // Video doesn't exist, proceed with download
  }
  
  // Download video from Google Drive
  console.log("Downloading hero video from Google Drive...");
  const googleDriveFileId = "1pxJpfL4XPamZXFR6PbESDhYawWn4Ll5S";
  const downloadUrl = `https://drive.google.com/uc?export=download&id=${googleDriveFileId}`;
  
  try {
    const response = await fetch(downloadUrl);
    if (!response.ok) {
      throw new Error(`Failed to download video: ${response.statusText}`);
    }
    
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    
    // Upload to MinIO
    console.log("Uploading hero video to MinIO...");
    await minioClient.putObject(
      bucketName,
      "hero-video.mp4",
      buffer,
      buffer.length,
      {
        "Content-Type": "video/mp4",
      }
    );
    console.log("Hero video uploaded successfully!");
  } catch (error) {
    console.error("Error downloading/uploading hero video:", error);
    console.log("Continuing without hero video...");
  }
}

async function setupBenefitsImage() {
  const bucketName = "public";
  
  // Always re-download to ensure we have the latest image
  console.log("Downloading benefits image from Google Drive...");
  const googleDriveFileId = "1vu14CDVHjGsRwwVrdbfetxiElKonG27q";
  const downloadUrl = `https://drive.google.com/uc?export=download&id=${googleDriveFileId}`;
  
  try {
    const response = await fetch(downloadUrl);
    if (!response.ok) {
      throw new Error(`Failed to download image: ${response.statusText}`);
    }
    
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    
    // Upload to MinIO (will overwrite if exists)
    console.log("Uploading benefits image to MinIO...");
    await minioClient.putObject(
      bucketName,
      "benefits-image.jpg",
      buffer,
      buffer.length,
      {
        "Content-Type": "image/jpeg",
      }
    );
    console.log("Benefits image uploaded successfully!");
  } catch (error) {
    console.error("Error downloading/uploading benefits image:", error);
    console.log("Continuing without benefits image...");
  }
}

async function setupHeroBadgeImage() {
  const bucketName = "public";
  
  // Always re-download to ensure we have the latest image
  console.log("Downloading hero badge image from Google Drive...");
  const googleDriveFileId = "1l9bA0PmRnFjFBo0nNtRIruRt-2vgrMad";
  const downloadUrl = `https://drive.google.com/uc?export=download&id=${googleDriveFileId}`;
  
  try {
    const response = await fetch(downloadUrl);
    if (!response.ok) {
      throw new Error(`Failed to download image: ${response.statusText}`);
    }
    
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    
    // Upload to MinIO (will overwrite if exists)
    console.log("Uploading hero badge image to MinIO...");
    await minioClient.putObject(
      bucketName,
      "hero-badge-image.png",
      buffer,
      buffer.length,
      {
        "Content-Type": "image/png",
      }
    );
    console.log("Hero badge image uploaded successfully!");
  } catch (error) {
    console.error("Error downloading/uploading hero badge image:", error);
    console.log("Continuing without hero badge image...");
  }
}

async function setup() {
  await setupMinIO();
  await setupBenefitsImage();
  await setupHeroBadgeImage();
  await seedData();
}

setup()
  .then(() => {
    console.log("setup.ts complete");
    process.exit(0);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
