import {
  createCallerFactory,
  createTRPCRouter,
} from "~/server/trpc/main";
import { getCameras } from "~/server/trpc/procedures/getCameras";
import { getRecentAlerts } from "~/server/trpc/procedures/getRecentAlerts";
import { updateCameraStatus } from "~/server/trpc/procedures/updateCameraStatus";
import { getHeroVideoUrl } from "~/server/trpc/procedures/getHeroVideoUrl";
import { getBenefitsImageUrl } from "~/server/trpc/procedures/getBenefitsImageUrl";
import { getHeroBadgeImageUrl } from "~/server/trpc/procedures/getHeroBadgeImageUrl";
import { addWaitlistEntry } from "~/server/trpc/procedures/addWaitlistEntry";

export const appRouter = createTRPCRouter({
  getCameras,
  getRecentAlerts,
  updateCameraStatus,
  getHeroVideoUrl,
  getBenefitsImageUrl,
  getHeroBadgeImageUrl,
  addWaitlistEntry,
});

export type AppRouter = typeof appRouter;

export const createCaller = createCallerFactory(appRouter);
