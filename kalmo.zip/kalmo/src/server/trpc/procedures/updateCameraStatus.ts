import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { db } from "~/server/db";
import { baseProcedure } from "~/server/trpc/main";

export const updateCameraStatus = baseProcedure
  .input(
    z.object({
      cameraId: z.number(),
      status: z.enum(['active', 'inactive', 'offline']).optional(),
      location: z.string().optional(),
    })
  )
  .mutation(async ({ input }) => {
    const camera = await db.camera.findUnique({
      where: { id: input.cameraId },
    });

    if (!camera) {
      throw new TRPCError({
        code: "NOT_FOUND",
        message: "Camera not found",
      });
    }

    const updatedCamera = await db.camera.update({
      where: { id: input.cameraId },
      data: {
        status: input.status,
        location: input.location,
        lastChecked: new Date(),
      },
    });

    return updatedCamera;
  });
