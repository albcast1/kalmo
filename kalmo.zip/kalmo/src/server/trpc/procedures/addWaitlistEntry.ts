import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { db } from "~/server/db";
import { baseProcedure } from "~/server/trpc/main";

export const addWaitlistEntry = baseProcedure
  .input(z.object({ email: z.string().email() }))
  .mutation(async ({ input }) => {
    try {
      await db.waitlistEntry.create({
        data: {
          email: input.email,
        },
      });
      
      return {
        success: true,
      };
    } catch (error: any) {
      // Handle duplicate email (Prisma unique constraint error)
      if (error.code === "P2002") {
        throw new TRPCError({
          code: "CONFLICT",
          message: "This email is already on the waitlist",
        });
      }
      
      // Re-throw other errors
      throw error;
    }
  });
