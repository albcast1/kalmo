import { baseProcedure } from "~/server/trpc/main";
import { minioBaseUrl } from "~/server/minio";

export const getHeroBadgeImageUrl = baseProcedure.query(async () => {
  const imageUrl = `${minioBaseUrl}/public/hero-badge-image.png`;
  return { imageUrl };
});
