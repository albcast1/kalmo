import { baseProcedure } from "~/server/trpc/main";
import { minioBaseUrl } from "~/server/minio";

export const getHeroVideoUrl = baseProcedure.query(async () => {
  const videoUrl = `${minioBaseUrl}/public/hero-video.mp4`;
  return { videoUrl };
});
