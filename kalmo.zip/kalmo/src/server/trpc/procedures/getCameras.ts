import { z } from "zod";
import { db } from "~/server/db";
import { baseProcedure } from "~/server/trpc/main";

export const getCameras = baseProcedure
  .input(z.object({ userId: z.number().optional() }))
  .query(async ({ input }) => {
    const cameras = await db.camera.findMany({
      where: input.userId ? { userId: input.userId } : undefined,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        alerts: {
          where: {
            resolved: false,
          },
          orderBy: {
            createdAt: 'desc',
          },
          take: 5,
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    return cameras;
  });
