import { z } from "zod";
import { db } from "~/server/db";
import { baseProcedure } from "~/server/trpc/main";

export const getRecentAlerts = baseProcedure
  .input(
    z.object({
      cursor: z.number().optional(),
      limit: z.number().min(1).max(50).default(10),
      severity: z.enum(['low', 'medium', 'high', 'critical']).optional(),
    })
  )
  .query(async ({ input }) => {
    const alerts = await db.alert.findMany({
      where: {
        severity: input.severity,
      },
      include: {
        camera: {
          select: {
            id: true,
            name: true,
            location: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
      take: input.limit + 1,
      skip: input.cursor ? 1 : 0,
      cursor: input.cursor ? { id: input.cursor } : undefined,
    });

    let nextCursor: number | undefined = undefined;
    if (alerts.length > input.limit) {
      const nextItem = alerts.pop();
      nextCursor = nextItem?.id;
    }

    return {
      alerts,
      nextCursor,
    };
  });
