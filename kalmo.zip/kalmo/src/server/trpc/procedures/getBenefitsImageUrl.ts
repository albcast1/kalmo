import { baseProcedure } from "~/server/trpc/main";
import { minioBaseUrl } from "~/server/minio";

export const getBenefitsImageUrl = baseProcedure.query(async () => {
  const imageUrl = `${minioBaseUrl}/public/benefits-image.jpg`;
  return { imageUrl };
});
