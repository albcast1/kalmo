import { createFileRoute, Outlet, redirect } from '@tanstack/react-router';

export const Route = createFileRoute('/$lang')({
  beforeLoad: ({ params }) => {
    // Only 'en' is valid for the $lang parameter
    // Spanish is the default (no parameter)
    if (params.lang !== 'en') {
      throw redirect({
        to: '/',
        replace: true,
      });
    }
  },
  component: LanguageLayout,
});

function LanguageLayout() {
  return <Outlet />;
}
