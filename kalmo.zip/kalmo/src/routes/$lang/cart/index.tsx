import { createFileRoute, Link } from "@tanstack/react-router";
import { Navigation } from "~/components/Navigation";
import { Footer } from "~/components/Footer";
import { NeumorphicCard } from "~/components/NeumorphicCard";
import { NeumorphicButton } from "~/components/NeumorphicButton";
import { NeumorphicInput } from "~/components/NeumorphicInput";
import { useTranslation } from "react-i18next";
import { useState } from "react";
import { AlertCircle, Video, CheckCircle } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useTRPC } from "~/trpc/react";
import toast from "react-hot-toast";
import { z } from "zod";
import { zodValidator } from "@tanstack/zod-adapter";

export const Route = createFileRoute("/$lang/cart/")({
  validateSearch: zodValidator(
    z.object({
      cameras: z.number().int().min(1).max(10).default(1),
    })
  ),
  component: Cart,
});

function Cart() {
  const { t } = useTranslation();
  const trpc = useTRPC();
  const { cameras } = Route.useSearch();
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Fetch the benefits image to use as product image
  const imageUrlQuery = useQuery(trpc.getBenefitsImageUrl.queryOptions());

  // Waitlist mutation
  const addToWaitlist = useMutation(
    trpc.addWaitlistEntry.mutationOptions({
      onSuccess: () => {
        setIsSubmitted(true);
        toast.success(t('cart.outOfStock.success'));
      },
      onError: (error: any) => {
        if (error.message?.includes("already on the waitlist")) {
          toast.error(t('cart.outOfStock.alreadyOnWaitlist'));
        } else {
          toast.error(t('cart.outOfStock.error'));
        }
      },
    })
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      addToWaitlist.mutate({ email });
    }
  };

  const CAMERA_ONE_OFF_PRICE = 69;
  const MONTHLY_PRICE_PER_CAMERA = 7.99;

  const totalOneOffPrice = CAMERA_ONE_OFF_PRICE * cameras;
  const totalMonthlyPrice = (MONTHLY_PRICE_PER_CAMERA * cameras).toFixed(2);

  return (
    <div className="min-h-screen bg-gradient-blue">
      <Navigation />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl sm:text-section-title text-wellness-gray mb-2">
            {t('cart.title')}
          </h1>
          <p className="text-sm sm:text-section-body text-wellness-gray/70">
            {t('cart.subtitle')}
          </p>
        </div>

        {/* Out of Stock State */}
        <NeumorphicCard padding="lg" shadow="xl" className="bg-white">
          <div className="space-y-8">
            {/* Product Display */}
            <div className="flex flex-col md:flex-row gap-6">
              {/* Product Image */}
              <div className="w-full md:w-1/3 rounded-wellness-lg overflow-hidden">
                {imageUrlQuery.data?.imageUrl ? (
                  <img 
                    src={imageUrlQuery.data.imageUrl}
                    alt="kalmo AI Camera"
                    className="w-full h-auto object-cover"
                  />
                ) : (
                  <div className="w-full aspect-square bg-wellness-gray/10 animate-pulse flex items-center justify-center">
                    <Video className="w-12 h-12 text-wellness-gray/30" />
                  </div>
                )}
              </div>

              {/* Product Info */}
              <div className="flex-1">
                <h2 className="text-xl sm:text-card-title text-wellness-gray mb-2">
                  {t('cart.items.camera')}
                </h2>
                <p className="text-sm sm:text-card-body text-wellness-gray/60 mb-6">
                  {t('cart.items.cameraDescription')}
                </p>

                {/* Pricing Info */}
                <div className="space-y-3 bg-transparent rounded-wellness p-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-wellness-gray/70">
                      {t('cart.items.price')} (pago único)
                    </span>
                    <span className="text-lg font-medium text-wellness-gray">
                      {totalOneOffPrice}€
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-wellness-gray/70">
                      Suscripción mensual
                    </span>
                    <span className="text-lg font-medium text-wellness-gray">
                      {totalMonthlyPrice}€/mes
                    </span>
                  </div>
                  <div className="border-t border-wellness-gray/10 pt-3 mt-3">
                    <p className="text-xs text-wellness-gray/60">
                      {cameras > 1 ? `${cameras} ${t('pricing.perCamera')}s` : t('pricing.perCamera')}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Out of Stock Notice */}
            <div className="border-t border-wellness-gray/10 pt-8">
              <div className="flex items-start space-x-3 mb-6">
                <AlertCircle className="w-6 h-6 text-orange-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-lg sm:text-card-title text-wellness-gray mb-2">
                    {t('cart.outOfStock.title')}
                  </h3>
                  <p className="text-sm sm:text-card-body text-wellness-gray/70">
                    {t('cart.outOfStock.description')}
                  </p>
                </div>
              </div>

              {/* Waitlist Form */}
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <NeumorphicInput
                    type="email"
                    placeholder={t('cart.outOfStock.emailPlaceholder')}
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    disabled={addToWaitlist.isPending}
                  />
                  <NeumorphicButton
                    type="submit"
                    variant="primary"
                    className="w-auto mx-auto"
                    size="md"
                    disabled={addToWaitlist.isPending}
                  >
                    {addToWaitlist.isPending ? 'Enviando...' : t('cart.outOfStock.notifyMe')}
                  </NeumorphicButton>
                </form>
              ) : (
                <div className="flex items-center justify-center space-x-3 py-6 bg-green-50 rounded-wellness">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                  <p className="text-sm font-medium text-green-800">
                    {t('cart.outOfStock.success')}
                  </p>
                </div>
              )}
            </div>
          </div>
        </NeumorphicCard>
      </div>

      <Footer />
    </div>
  );
}
