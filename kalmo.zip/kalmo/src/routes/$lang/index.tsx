import { createFileRoute } from "@tanstack/react-router";
import { Navigation } from "~/components/Navigation";
import { Hero } from "~/components/Hero";
import { Benefits } from "~/components/Benefits";
import { HowItWorks } from "~/components/HowItWorks";
import { Pricing } from "~/components/Pricing";
import { CTA } from "~/components/CTA";
import { Footer } from "~/components/Footer";

export const Route = createFileRoute("/$lang/")({
  component: Home,
});

function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <Hero />
      <Benefits />
      <HowItWorks />
      <Pricing />
      <CTA />
      <Footer />
    </div>
  );
}
