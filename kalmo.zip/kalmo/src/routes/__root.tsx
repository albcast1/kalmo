import { useEffect } from 'react';
import {
  Outlet,
  createRootRoute,
  useRouterState,
} from "@tanstack/react-router";
import { useTranslation } from 'react-i18next';
import { TRPCReactProvider } from "~/trpc/react";
import { useLanguageStore } from '~/stores/languageStore';

export const Route = createRootRoute({
  component: RootComponent,
});

function RootComponent() {
  const isFetching = useRouterState({ select: (s) => s.isLoading });
  const { i18n } = useTranslation();
  const { language, setLanguage } = useLanguageStore();
  const location = useRouterState({ select: (s) => s.location });

  // Sync language from URL path
  useEffect(() => {
    const pathLang = location.pathname.startsWith('/en') ? 'en' : 'es';
    
    // Update i18n language if it differs from path
    if (i18n.language !== pathLang) {
      i18n.changeLanguage(pathLang);
    }
    
    // Update store if it differs from path
    if (language !== pathLang) {
      setLanguage(pathLang);
    }
  }, [location.pathname, i18n, language, setLanguage]);

  if (isFetching) {
    return (
      <div className="min-h-screen bg-gradient-wellness flex items-center justify-center">
        <div className="text-center space-y-6">
          <div className="space-y-2">
            <p className="text-4xl font-logo text-wellness-gray animate-pulse">kalmo</p>
            <p className="text-meta text-wellness-gray/60">Loading...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <TRPCReactProvider>
      <Outlet />
    </TRPCReactProvider>
  );
}
