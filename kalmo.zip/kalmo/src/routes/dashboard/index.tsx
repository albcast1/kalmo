import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTRPC } from "~/trpc/react";
import { Navigation } from "~/components/Navigation";
import { NeumorphicCard } from "~/components/NeumorphicCard";
import { NeumorphicButton } from "~/components/NeumorphicButton";
import { DashboardStats } from "~/components/DashboardStats";
import { 
  Video, 
  AlertCircle, 
  CheckCircle, 
  XCircle, 
  MapPin, 
  Clock,
  Filter,
  Activity
} from "lucide-react";
import { useState } from "react";
import { useTranslation } from "react-i18next";

export const Route = createFileRoute("/dashboard/")({
  component: Dashboard,
});

function Dashboard() {
  const { t } = useTranslation();
  const trpc = useTRPC();
  const queryClient = useQueryClient();
  const [selectedSeverity, setSelectedSeverity] = useState<'low' | 'medium' | 'high' | 'critical' | undefined>(undefined);

  // Query for cameras
  const camerasQuery = useQuery(trpc.getCameras.queryOptions({}));

  // Query for recent alerts
  const alertsQuery = useQuery(
    trpc.getRecentAlerts.queryOptions(
      { limit: 10, severity: selectedSeverity },
      { refetchInterval: 5000 } // Refetch every 5 seconds
    )
  );

  // Mutation for updating camera status
  const updateCameraStatusMutation = useMutation(
    trpc.updateCameraStatus.mutationOptions({
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: trpc.getCameras.queryKey() });
      },
    })
  );

  const totalCameras = camerasQuery.data?.length || 0;
  const activeCameras = camerasQuery.data?.filter(c => c.status === 'active').length || 0;
  const totalAlerts = alertsQuery.data?.alerts.length || 0;
  const criticalAlerts = alertsQuery.data?.alerts.filter(a => a.severity === 'critical' && !a.resolved).length || 0;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'text-green-600';
      case 'inactive':
        return 'text-amber-600';
      case 'offline':
        return 'text-red-600';
      default:
        return 'text-wellness-gray/60';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return CheckCircle;
      case 'inactive':
        return AlertCircle;
      case 'offline':
        return XCircle;
      default:
        return Activity;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-100/80 text-red-700 border border-red-200/50';
      case 'high':
        return 'bg-orange-100/80 text-orange-700 border border-orange-200/50';
      case 'medium':
        return 'bg-amber-100/80 text-amber-700 border border-amber-200/50';
      case 'low':
        return 'bg-blue-100/80 text-blue-700 border border-blue-200/50';
      default:
        return 'bg-wellness-gray/5 text-wellness-gray border border-wellness-gray/10';
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffDays > 0) return t('dashboard.cameras.timeAgo.daysAgo', { count: diffDays });
    if (diffHours > 0) return t('dashboard.cameras.timeAgo.hoursAgo', { count: diffHours });
    if (diffMins > 0) return t('dashboard.cameras.timeAgo.minutesAgo', { count: diffMins });
    return t('dashboard.cameras.timeAgo.justNow');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-wellness-beige via-wellness-yellow to-wellness-blue">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-title text-wellness-gray mb-4">
            {t('dashboard.title')}
          </h1>
          <p className="text-body text-wellness-gray/60">
            {t('dashboard.subtitle')}
          </p>
        </div>

        {/* Stats Overview */}
        {!camerasQuery.isLoading && !alertsQuery.isLoading && (
          <DashboardStats
            totalCameras={totalCameras}
            activeCameras={activeCameras}
            totalAlerts={totalAlerts}
            criticalAlerts={criticalAlerts}
          />
        )}

        {/* Cameras Section */}
        <section className="mb-12">
          <h2 className="text-heading text-wellness-gray mb-6">{t('dashboard.cameras.title')}</h2>
          
          {camerasQuery.isLoading ? (
            <div className="text-center py-12">
              <p className="text-body text-wellness-gray/60">{t('dashboard.cameras.loading')}</p>
            </div>
          ) : camerasQuery.isError ? (
            <div className="text-center py-12">
              <p className="text-body text-red-600">{t('dashboard.cameras.error')}</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {camerasQuery.data?.map((camera) => {
                const StatusIcon = getStatusIcon(camera.status);
                return (
                  <NeumorphicCard key={camera.id} padding="lg" className="hover:shadow-soft-lg transition-all duration-300">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 rounded-wellness bg-gradient-to-br from-wellness-beige to-wellness-yellow shadow-soft flex items-center justify-center border border-wellness-gray/5">
                            <Video className="w-6 h-6 text-wellness-gray" strokeWidth={1.5} />
                          </div>
                          <div>
                            <h3 className="text-card-title text-wellness-gray">{camera.name}</h3>
                            <div className="flex items-center space-x-1 text-body-sm">
                              <StatusIcon className={`w-4 h-4 ${getStatusColor(camera.status)}`} strokeWidth={2} />
                              <span className={getStatusColor(camera.status)}>
                                {t(`dashboard.cameras.status.${camera.status}`)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 text-body-sm text-wellness-gray/70">
                        <MapPin className="w-4 h-4" strokeWidth={2} />
                        <span>{camera.location}</span>
                      </div>

                      <div className="flex items-center space-x-2 text-body-sm text-wellness-gray/70">
                        <Clock className="w-4 h-4" strokeWidth={2} />
                        <span>{t('dashboard.cameras.lastChecked')}: {formatTimeAgo(camera.lastChecked)}</span>
                      </div>

                      {camera.alerts.length > 0 && (
                        <div className="pt-4 border-t border-wellness-gray/10">
                          <p className="text-body-sm text-wellness-gray mb-2">
                            {camera.alerts.length} {camera.alerts.length === 1 ? t('dashboard.cameras.unresolvedAlerts') : t('dashboard.cameras.unresolvedAlertsPlural')}
                          </p>
                        </div>
                      )}

                      <div className="flex gap-2">
                        <NeumorphicButton
                          size="sm"
                          variant="secondary"
                          className="flex-1"
                          onClick={() => {
                            updateCameraStatusMutation.mutate({
                              cameraId: camera.id,
                              status: camera.status === 'active' ? 'inactive' : 'active',
                            });
                          }}
                          disabled={updateCameraStatusMutation.isPending}
                        >
                          {camera.status === 'active' ? t('dashboard.cameras.deactivate') : t('dashboard.cameras.activate')}
                        </NeumorphicButton>
                      </div>
                    </div>
                  </NeumorphicCard>
                );
              })}
            </div>
          )}
        </section>

        {/* Alerts Section */}
        <section>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
            <h2 className="text-heading text-wellness-gray">{t('dashboard.alerts.title')}</h2>
            
            <div className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-wellness-gray/60" strokeWidth={2} />
              <select
                value={selectedSeverity || ''}
                onChange={(e) => setSelectedSeverity(e.target.value as any || undefined)}
                className="px-4 py-2 rounded-wellness bg-white/90 shadow-soft text-wellness-gray outline-none border border-wellness-gray/10 text-caption transition-all duration-300 focus:border-wellness-gray/30 focus:shadow-soft-sm"
              >
                <option value="">{t('dashboard.alerts.filterBySeverity')}</option>
                <option value="low">{t('dashboard.alerts.severity.low')}</option>
                <option value="medium">{t('dashboard.alerts.severity.medium')}</option>
                <option value="high">{t('dashboard.alerts.severity.high')}</option>
                <option value="critical">{t('dashboard.alerts.severity.critical')}</option>
              </select>
            </div>
          </div>

          {alertsQuery.isLoading ? (
            <div className="text-center py-12">
              <p className="text-body text-wellness-gray/60">{t('dashboard.alerts.loading')}</p>
            </div>
          ) : alertsQuery.isError ? (
            <div className="text-center py-12">
              <p className="text-body text-red-600">{t('dashboard.alerts.error')}</p>
            </div>
          ) : alertsQuery.data?.alerts.length === 0 ? (
            <NeumorphicCard padding="lg">
              <div className="text-center py-12">
                <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" strokeWidth={1.5} />
                <p className="text-body text-wellness-gray/60">{t('dashboard.alerts.noAlerts')}</p>
              </div>
            </NeumorphicCard>
          ) : (
            <div className="space-y-4">
              {alertsQuery.data?.alerts.map((alert) => (
                <NeumorphicCard key={alert.id} padding="lg" className="hover:shadow-soft-lg transition-all duration-300">
                  <div className="flex flex-col md:flex-row gap-6">
                    {alert.imageUrl && (
                      <div className="md:w-48 h-32 rounded-wellness overflow-hidden shadow-soft flex-shrink-0 border border-wellness-gray/5">
                        <img
                          src={alert.imageUrl}
                          alt="Alert"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                    
                    <div className="flex-grow space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center space-x-3 mb-2">
                            <span className={`px-3 py-1 rounded-wellness text-tiny ${getSeverityColor(alert.severity)}`}>
                              {t(`dashboard.alerts.severity.${alert.severity}`)}
                            </span>
                            <span className="px-3 py-1 rounded-wellness text-tiny bg-wellness-gray/5 text-wellness-gray border border-wellness-gray/10">
                              {alert.type}
                            </span>
                          </div>
                          <h3 className="text-subheading text-wellness-gray">
                            {alert.description}
                          </h3>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-body-sm text-wellness-gray/70">
                        <div className="flex items-center space-x-1">
                          <Video className="w-4 h-4" strokeWidth={2} />
                          <span>{alert.camera.name}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <MapPin className="w-4 h-4" strokeWidth={2} />
                          <span>{alert.camera.location}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" strokeWidth={2} />
                          <span>{formatTimeAgo(alert.createdAt)}</span>
                        </div>
                      </div>

                      {!alert.resolved && (
                        <div className="flex gap-2 pt-2">
                          <NeumorphicButton size="sm" variant="primary">
                            {t('dashboard.alerts.viewDetails')}
                          </NeumorphicButton>
                          <NeumorphicButton size="sm" variant="secondary">
                            {t('dashboard.alerts.markResolved')}
                          </NeumorphicButton>
                        </div>
                      )}
                    </div>
                  </div>
                </NeumorphicCard>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
