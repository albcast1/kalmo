import { InputHTMLAttributes, forwardRef } from 'react';
import { cn } from '~/utils/cn';

interface NeumorphicInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const NeumorphicInput = forwardRef<HTMLInputElement, NeumorphicInputProps>(
  ({ className, label, error, ...props }, ref) => {
    return (
      <div className="w-full">
        {label && (
          <label className="block text-label text-wellness-gray mb-2">
            {label}
          </label>
        )}
        <input
          ref={ref}
          className={cn(
            'w-full px-4 py-3 rounded-wellness bg-white/90 border border-wellness-gray/10',
            'text-body text-wellness-gray placeholder-wellness-gray/40',
            'outline-none transition-all duration-300',
            'focus:border-wellness-gray/30 focus:shadow-soft-sm focus:bg-white',
            'hover:border-wellness-gray/20',
            error && 'border-red-400 focus:border-red-400',
            className
          )}
          {...props}
        />
        {error && (
          <p className="mt-1.5 text-caption text-red-500">{error}</p>
        )}
      </div>
    );
  }
);

NeumorphicInput.displayName = 'NeumorphicInput';
