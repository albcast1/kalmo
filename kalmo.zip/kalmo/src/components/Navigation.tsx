import { Link } from '@tanstack/react-router';
import { useTranslation } from 'react-i18next';
import { useNavigate, useRouterState } from '@tanstack/react-router';
import { Languages } from 'lucide-react';
import { NeumorphicButton } from './NeumorphicButton';

export function Navigation() {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const location = useRouterState({ select: (s) => s.location });
  
  const currentLang = i18n.language;
  const isEnglish = currentLang === 'en';

  const toggleLanguage = () => {
    const newLang = isEnglish ? 'es' : 'en';
    
    // Get the current path without language prefix
    let pathWithoutLang = location.pathname;
    if (pathWithoutLang.startsWith('/en')) {
      pathWithoutLang = pathWithoutLang.substring(3) || '/';
    }
    
    // Navigate to the new language path
    const newPath = newLang === 'en' ? `/en${pathWithoutLang}` : pathWithoutLang;
    navigate({ to: newPath });
  };

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-wellness-gray/5 shadow-soft-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to={isEnglish ? "/en" : "/"} className="flex items-center group">
            <span className="text-xl sm:text-logo font-logo text-wellness-gray">kalmo</span>
          </Link>

          {/* Navigation Links and CTA Buttons */}
          <div className="flex items-center space-x-8">
            <a 
              href="#how-it-works" 
              className="hidden sm:block text-xs sm:text-caption text-wellness-gray/70 hover:text-wellness-gray transition-colors duration-300"
            >
              {t('nav.howItWorks')}
            </a>
            <a 
              href="#pricing" 
              className="hidden sm:block text-xs sm:text-caption text-wellness-gray/70 hover:text-wellness-gray transition-colors duration-300"
            >
              {t('nav.pricing')}
            </a>
            
            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-2 px-3 py-2 rounded-wellness bg-wellness-gray/5 hover:bg-wellness-gray/10 transition-colors duration-300"
              title={isEnglish ? 'Cambiar a Español' : 'Switch to English'}
            >
              <Languages className="w-4 h-4 text-wellness-gray/70" strokeWidth={2} />
              <span className="text-xs sm:text-caption text-wellness-gray/70">
                {isEnglish ? 'ES' : 'EN'}
              </span>
            </button>
            
            <a href="#pricing">
              <NeumorphicButton variant="primary" size="sm">
                {t('nav.subscribe')}
              </NeumorphicButton>
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}
