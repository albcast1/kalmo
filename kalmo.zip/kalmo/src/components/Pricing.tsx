import { useState } from 'react';
import { NeumorphicCard } from './NeumorphicCard';
import { NeumorphicButton } from './NeumorphicButton';
import { Check, Minus, Plus } from 'lucide-react';
import { useNavigate } from '@tanstack/react-router';
import { useTranslation } from 'react-i18next';
import { cn } from '~/utils/cn';

export function Pricing() {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const [cameras, setCameras] = useState(2);

  const MONTHLY_PRICE_PER_CAMERA = 7.99;
  const ANNUAL_PRICE_PER_CAMERA = 6.99;
  const CAMERA_ONE_OFF_PRICE = 69;

  const calculateMonthlyTotal = (cameras: number) => {
    return (cameras * MONTHLY_PRICE_PER_CAMERA).toFixed(2);
  };

  const calculateAnnualTotal = (cameras: number) => {
    return (cameras * ANNUAL_PRICE_PER_CAMERA).toFixed(2);
  };

  const calculateCamerasCost = (cameras: number) => {
    return cameras * CAMERA_ONE_OFF_PRICE;
  };

  const plans = [
    {
      id: 'monthly',
      name: t('pricing.monthly.name'),
      description: t('pricing.monthly.description'),
      pricePerCamera: MONTHLY_PRICE_PER_CAMERA,
      period: t('pricing.monthly.period'),
      features: t('pricing.monthly.features', { returnObjects: true }) as string[],
      cta: t('pricing.monthly.cta'),
      calculateTotal: calculateMonthlyTotal,
      recommended: false,
    },
    {
      id: 'annual',
      name: t('pricing.annual.name'),
      description: t('pricing.annual.description'),
      pricePerCamera: ANNUAL_PRICE_PER_CAMERA,
      period: t('pricing.annual.period'),
      features: t('pricing.annual.features', { returnObjects: true }) as string[],
      cta: t('pricing.annual.cta'),
      calculateTotal: calculateAnnualTotal,
      recommended: true,
      savingsPercentage: 12.5,
    },
  ];

  return (
    <section id="pricing" className="py-20 bg-gradient-pricing">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-2xl sm:text-section-title text-wellness-gray mb-8">
            {t('pricing.title')}
          </h2>
          <p className="text-sm sm:text-section-body text-wellness-gray/60 max-w-2xl mx-auto">
            {t('pricing.subtitle')}
          </p>
        </div>

        {/* Unified Camera Selector */}
        <div className="max-w-xs mx-auto mb-12">
          <NeumorphicCard padding="sm" shadow="md" className="bg-white">
            <div className="space-y-2">
              <label className="block text-xs sm:text-caption text-wellness-gray text-center">
                {t('pricing.cameraSelector.label')}
              </label>
              <div className="flex items-center justify-center space-x-4">
                <NeumorphicButton
                  variant="secondary"
                  size="sm"
                  onClick={() => setCameras(Math.max(1, cameras - 1))}
                  disabled={cameras <= 1}
                  className="w-8 h-8 p-0 flex items-center justify-center"
                >
                  <Minus className="w-4 h-4" />
                </NeumorphicButton>
                <span className="text-xl sm:text-subheading text-wellness-gray min-w-[3rem] text-center">
                  {cameras}
                </span>
                <NeumorphicButton
                  variant="secondary"
                  size="sm"
                  onClick={() => setCameras(Math.min(10, cameras + 1))}
                  disabled={cameras >= 10}
                  className="w-8 h-8 p-0 flex items-center justify-center"
                >
                  <Plus className="w-4 h-4" />
                </NeumorphicButton>
              </div>
            </div>
          </NeumorphicCard>
        </div>

        {/* Pricing Plans */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto items-start mb-12">
          {plans.map((plan) => (
            <NeumorphicCard
              key={plan.id}
              padding="md"
              shadow={plan.recommended ? 'xl' : 'md'}
              className={cn(
                'relative bg-white hover:shadow-soft-xl transition-all duration-300',
                plan.recommended ? 'border-wellness-gray/10' : ''
              )}
            >
              {plan.recommended && 'savingsPercentage' in plan && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-6 py-2 rounded-wellness bg-wellness-gray shadow-soft text-caption font-semibold text-white">
                  {t('pricing.savePercentage', { percentage: plan.savingsPercentage })}
                </div>
              )}

              <div className="space-y-6">
                <div>
                  <h3 className="text-sm sm:text-card-title text-wellness-gray mb-3">
                    {plan.name}
                  </h3>
                  <p className="text-xs sm:text-section-body text-wellness-gray/70">
                    {plan.description}
                  </p>
                </div>

                {/* Subscription Price */}
                <div className="space-y-2 py-4">
                  <div className="flex items-baseline justify-center">
                    <span className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-normal text-wellness-gray">
                      {plan.calculateTotal(cameras)}€
                    </span>
                    <span className="ml-3 text-body text-wellness-gray/60">
                      / {plan.period}
                    </span>
                  </div>
                  <p className="text-[0.625rem] sm:text-tiny text-wellness-gray/50 text-center">
                    {plan.pricePerCamera}€ {t('pricing.perCamera')} / {plan.period}
                  </p>
                </div>

                <NeumorphicButton
                  variant={plan.recommended ? 'primary' : 'secondary'}
                  className="w-full"
                  onClick={() => {
                    const currentLang = i18n.language;
                    const cartPath = currentLang === 'en' ? '/en/cart' : '/cart';
                    navigate({ to: cartPath, search: { cameras } });
                  }}
                >
                  {plan.cta}
                </NeumorphicButton>

                <div className="space-y-4 pt-6 border-t border-wellness-gray/10">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-start space-x-3">
                      <div className="w-5 h-5 rounded-full bg-wellness-gray/5 shadow-soft-xs flex items-center justify-center flex-shrink-0 mt-0.5 border border-wellness-gray/10">
                        <Check className="w-3 h-3 text-wellness-gray" strokeWidth={2.5} />
                      </div>
                      <span className="text-xs sm:text-section-body text-wellness-gray/80">
                        {feature}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </NeumorphicCard>
          ))}
        </div>

        {/* Camera One-off Price - Full Width Block */}
        <div className="max-w-4xl mx-auto">
          <NeumorphicCard padding="md" shadow="lg" className="bg-white border-wellness-gray/10">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
              <div className="space-y-2">
                <h4 className="text-sm sm:text-card-title text-wellness-gray">
                  {t('pricing.cameraPrice.label')}
                </h4>
                <p className="text-xs sm:text-caption text-wellness-gray/60">
                  {cameras > 1 
                    ? `${CAMERA_ONE_OFF_PRICE}€ × ${cameras} cameras`
                    : `${CAMERA_ONE_OFF_PRICE}€ per camera`
                  }
                </p>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <div className="text-xl sm:text-2xl md:text-3xl font-medium text-wellness-gray">
                    {calculateCamerasCost(cameras)}€
                  </div>
                  <p className="text-[0.625rem] sm:text-tiny text-wellness-gray/50 mt-1">
                    One-time payment
                  </p>
                </div>
              </div>
            </div>
          </NeumorphicCard>
        </div>
      </div>
    </section>
  );
}
