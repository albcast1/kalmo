import { HTMLAttributes, forwardRef } from 'react';
import { cn } from '~/utils/cn';

interface NeumorphicCardProps extends HTMLAttributes<HTMLDivElement> {
  padding?: 'none' | 'sm' | 'md' | 'lg';
  shadow?: 'none' | 'xs' | 'sm' | 'md' | 'lg' | 'xl';
}

export const NeumorphicCard = forwardRef<HTMLDivElement, NeumorphicCardProps>(
  ({ className, padding = 'md', shadow = 'md', children, ...props }, ref) => {
    const paddingStyles = {
      none: '',
      sm: 'p-4',
      md: 'p-6',
      lg: 'p-8',
    };

    const shadowStyles = {
      none: '',
      xs: 'shadow-soft-xs',
      sm: 'shadow-soft-sm',
      md: 'shadow-soft',
      lg: 'shadow-soft-lg',
      xl: 'shadow-soft-xl',
    };

    return (
      <div
        ref={ref}
        className={cn(
          'rounded-wellness-lg border border-wellness-gray/5',
          paddingStyles[padding],
          shadowStyles[shadow],
          'transition-shadow duration-300',
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

NeumorphicCard.displayName = 'NeumorphicCard';
