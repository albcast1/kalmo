import { NeumorphicCard } from './NeumorphicCard';
import { Video, Activity, AlertCircle, AlertTriangle } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface DashboardStatsProps {
  totalCameras: number;
  activeCameras: number;
  totalAlerts: number;
  criticalAlerts: number;
}

export function DashboardStats({ 
  totalCameras, 
  activeCameras, 
  totalAlerts, 
  criticalAlerts 
}: DashboardStatsProps) {
  const { t } = useTranslation();
  
  const stats = [
    {
      label: t('dashboard.stats.totalCameras'),
      value: totalCameras,
      icon: Video,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      label: t('dashboard.stats.activeCameras'),
      value: activeCameras,
      icon: Activity,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
    {
      label: t('dashboard.stats.totalAlerts'),
      value: totalAlerts,
      icon: AlertCircle,
      color: 'text-amber-600',
      bgColor: 'bg-amber-50',
    },
    {
      label: t('dashboard.stats.criticalAlerts'),
      value: criticalAlerts,
      icon: AlertTriangle,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <NeumorphicCard key={index} padding="lg" className="bg-wellness-light-beige hover:shadow-soft-lg transition-shadow duration-300">
            <div className="flex items-center space-x-4">
              <div className={`w-14 h-14 rounded-wellness ${stat.bgColor} shadow-soft-xs flex items-center justify-center flex-shrink-0 border border-wellness-gray/5`}>
                <Icon className={`w-7 h-7 ${stat.color}`} strokeWidth={1.5} />
              </div>
              <div>
                <p className="text-heading font-semibold text-wellness-gray">{stat.value}</p>
                <p className="text-caption text-wellness-gray/60">{stat.label}</p>
              </div>
            </div>
          </NeumorphicCard>
        );
      })}
    </div>
  );
}
