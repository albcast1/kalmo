import { Mail, Phone, MapPin } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export function Footer() {
  const { t } = useTranslation();
  
  return (
    <footer className="bg-white py-20 border-t border-wellness-gray/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-14 mb-14">
          {/* Company Info */}
          <div className="space-y-6">
            <div className="flex items-center">
              <span className="text-logo font-logo text-wellness-gray">kalmo</span>
            </div>
            <p className="text-body-sm text-wellness-gray/70 leading-relaxed">
              {t('footer.description')}
            </p>
          </div>

          {/* Product */}
          <div>
            <h3 className="text-subheading text-wellness-gray mb-6">{t('footer.product')}</h3>
            <ul className="space-y-4 text-body-sm text-wellness-gray/70">
              <li><a href="#how-it-works" className="hover:text-wellness-gray transition-colors">{t('footer.howItWorks')}</a></li>
              <li><a href="#pricing" className="hover:text-wellness-gray transition-colors">{t('footer.pricing')}</a></li>
              <li><a href="#" className="hover:text-wellness-gray transition-colors">{t('footer.faq')}</a></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-subheading text-wellness-gray mb-6">{t('footer.company')}</h3>
            <ul className="space-y-4 text-body-sm text-wellness-gray/70">
              <li><a href="#" className="hover:text-wellness-gray transition-colors">{t('footer.aboutUs')}</a></li>
              <li><a href="#" className="hover:text-wellness-gray transition-colors">{t('footer.careers')}</a></li>
              <li><a href="#" className="hover:text-wellness-gray transition-colors">{t('footer.press')}</a></li>
              <li><a href="#" className="hover:text-wellness-gray transition-colors">{t('footer.contact')}</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-subheading text-wellness-gray mb-6">{t('footer.contactTitle')}</h3>
            <ul className="space-y-5 text-body-sm text-wellness-gray/70">
              <li className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-wellness-gray/50" strokeWidth={2} />
                <span>{t('footer.email')}</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-wellness-gray/50" strokeWidth={2} />
                <span>{t('footer.phone')}</span>
              </li>
              <li className="flex items-center space-x-3">
                <MapPin className="w-4 h-4 text-wellness-gray/50" strokeWidth={2} />
                <span>{t('footer.location')}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-10 border-t border-wellness-gray/5 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-caption text-wellness-gray/60">
            {t('footer.copyright')}
          </p>
          <div className="flex space-x-8 text-caption text-wellness-gray/60">
            <a href="#" className="hover:text-wellness-gray transition-colors">{t('footer.privacyPolicy')}</a>
            <a href="#" className="hover:text-wellness-gray transition-colors">{t('footer.termsOfService')}</a>
            <a href="#" className="hover:text-wellness-gray transition-colors">{t('footer.cookiePolicy')}</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
