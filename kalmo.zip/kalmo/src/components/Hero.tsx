import { NeumorphicButton } from './NeumorphicButton';
import { NeumorphicCard } from './NeumorphicCard';
import { Video } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { useTRPC } from '~/trpc/react';
import { useTranslation } from 'react-i18next';

export function Hero() {
  const { t } = useTranslation();
  const trpc = useTRPC();
  const videoUrlQuery = useQuery(trpc.getHeroVideoUrl.queryOptions());
  const badgeImageQuery = useQuery(trpc.getHeroBadgeImageUrl.queryOptions());
  
  return (
    <section className="relative bg-gradient-blue py-6 md:py-16 overflow-hidden">
      {/* Subtle geometric accent */}
      <div className="absolute top-20 right-10 w-64 h-64 bg-wellness-yellow/20 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-wellness-blue/30 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-8 md:gap-16 lg:gap-24 items-center">
          {/* Left column - Text content */}
          <div className="space-y-6 md:space-y-10">
            {badgeImageQuery.data?.imageUrl && (
              <div className="mb-1 md:mb-2">
                <img 
                  src={badgeImageQuery.data.imageUrl}
                  alt="Trust badge"
                  className="h-20 w-auto object-contain"
                />
              </div>
            )}
            
            <div className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-wellness bg-white/60 backdrop-blur-sm shadow-soft-sm border border-wellness-gray/5">
              <Video className="w-4 h-4 text-wellness-gray" strokeWidth={2} />
              <span className="text-xs sm:text-caption text-wellness-gray">
                {t('hero.badge')}
              </span>
            </div>

            <h1 className="text-[2rem] sm:text-hero-title text-wellness-gray text-left leading-tight">
              {t('hero.title')}
            </h1>

            <p className="text-sm sm:text-hero-subtitle text-wellness-gray/80 max-w-xl lg:max-w-xl">
              {t('hero.description')}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-row gap-3 md:gap-5 pt-4 md:pt-6">
              <a href="#pricing">
                <NeumorphicButton variant="primary" size="md">
                  {t('hero.ctaSubscribe')}
                </NeumorphicButton>
              </a>
              <a href="#benefits">
                <NeumorphicButton variant="secondary" size="md">
                  {t('hero.ctaBuyNow')}
                </NeumorphicButton>
              </a>
            </div>

            <p className="text-xs sm:text-caption text-wellness-gray/60">
              {t('hero.features')}
            </p>
          </div>

          {/* Right column - Product video clip */}
          <div className="relative max-w-lg ml-auto">
            {/* Video clip - simple and clean */}
            <div className="rounded-wellness-lg overflow-hidden shadow-soft-lg">
              {videoUrlQuery.data?.videoUrl ? (
                <video
                  src={videoUrlQuery.data.videoUrl}
                  className="w-full h-full object-cover aspect-video lg:aspect-[4/3]"
                  autoPlay
                  loop
                  muted
                  playsInline
                  title="Elderly care monitoring demonstration"
                />
              ) : (
                <div className="w-full aspect-video lg:aspect-[4/3] bg-wellness-gray/10 animate-pulse flex items-center justify-center">
                  <Video className="w-12 h-12 text-wellness-gray/30" />
                </div>
              )}
            </div>

            {/* Floating stats */}
            <div className="absolute -bottom-3 -left-3 hidden lg:block">
              <NeumorphicCard padding="none" className="bg-wellness-light-beige">
                <div className="text-center px-3 py-2">
                  <div className="text-xs sm:text-body-sm font-semibold text-wellness-gray">98%</div>
                  <div className="text-[0.625rem] sm:text-tiny text-wellness-gray/60 whitespace-nowrap">{t('hero.accuracy')}</div>
                </div>
              </NeumorphicCard>
            </div>

            <div className="absolute -top-3 -right-3 hidden lg:block">
              <NeumorphicCard padding="none" className="bg-wellness-light-beige">
                <div className="flex items-center gap-2 px-3 py-2">
                  <div className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></div>
                  <div className="text-xs sm:text-body-sm font-semibold text-wellness-gray">{t('hero.recording')}</div>
                </div>
              </NeumorphicCard>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
