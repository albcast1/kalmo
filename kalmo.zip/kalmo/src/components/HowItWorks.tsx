import { NeumorphicCard } from './NeumorphicCard';
import { useTranslation } from 'react-i18next';

export function HowItWorks() {
  const { t } = useTranslation();
  
  const steps = [
    {
      number: '01',
      title: t('howItWorks.step1.title'),
      description: t('howItWorks.step1.description'),
    },
    {
      number: '02',
      title: t('howItWorks.step2.title'),
      description: t('howItWorks.step2.description'),
    },
    {
      number: '03',
      title: t('howItWorks.step3.title'),
      description: t('howItWorks.step3.description'),
    },
    {
      number: '04',
      title: t('howItWorks.step4.title'),
      description: t('howItWorks.step4.description'),
    },
  ];

  return (
    <section id="how-it-works" className="py-16 bg-gradient-sandy relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-24">
          <h2 className="text-2xl sm:text-section-title text-white mb-8">
            {t('howItWorks.title')}
          </h2>
          <p className="text-sm sm:text-section-body text-white/70 max-w-2xl mx-auto">
            {t('howItWorks.subtitle')}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {steps.map((step, index) => {
            return (
              <div key={index} className="relative">
                <NeumorphicCard padding="lg" shadow="none" className="h-full bg-gradient-sandy-card transition-shadow duration-300">
                  <div className="space-y-6">
                    <div className="flex items-center justify-start">
                      <span className="text-sm sm:text-section-subtitle text-white">{step.number}</span>
                    </div>
                    <h3 className="text-sm sm:text-section-subtitle text-white">{step.title}</h3>
                    <p className="text-xs sm:text-section-body text-white/70">{step.description}</p>
                  </div>
                </NeumorphicCard>
                
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 w-8 h-0.5 bg-gradient-to-r from-white/20 to-transparent"></div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
