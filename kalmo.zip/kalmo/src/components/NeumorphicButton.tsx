import { ButtonHTMLAttributes, forwardRef } from 'react';
import { cn } from '~/utils/cn';

interface NeumorphicButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
}

export const NeumorphicButton = forwardRef<HTMLButtonElement, NeumorphicButtonProps>(
  ({ className, variant = 'primary', size = 'md', children, ...props }, ref) => {
    const baseStyles = 'rounded-wellness transition-all duration-300 ease-out border border-transparent';
    
    const variantStyles = {
      primary: 'bg-wellness-gray text-white shadow-soft hover:shadow-soft-md hover:scale-[1.02] active:scale-[0.98] active:shadow-soft-sm',
      secondary: 'bg-white text-wellness-gray shadow-soft hover:shadow-soft-md hover:scale-[1.02] active:scale-[0.98] active:shadow-soft-sm border-wellness-gray/10',
      ghost: 'bg-transparent text-wellness-gray hover:bg-white/50 hover:shadow-soft-sm active:bg-white/70',
    };

    const sizeStyles = {
      sm: 'px-5 py-2.5 text-button-sm',
      md: 'px-7 py-3.5 text-button',
      lg: 'px-9 py-4 text-button-lg',
    };

    return (
      <button
        ref={ref}
        className={cn(
          baseStyles,
          variantStyles[variant],
          sizeStyles[size],
          'disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100',
          className
        )}
        {...props}
      >
        {children}
      </button>
    );
  }
);

NeumorphicButton.displayName = 'NeumorphicButton';
