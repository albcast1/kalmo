import { NeumorphicCard } from './NeumorphicCard';
import { Star } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export function Testimonials() {
  const { t } = useTranslation();
  
  const testimonials = [
    {
      name: t('testimonials.testimonial1.name'),
      role: t('testimonials.testimonial1.role'),
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&q=80',
      content: t('testimonials.testimonial1.content'),
      rating: 5,
    },
    {
      name: t('testimonials.testimonial2.name'),
      role: t('testimonials.testimonial2.role'),
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&q=80',
      content: t('testimonials.testimonial2.content'),
      rating: 5,
    },
    {
      name: t('testimonials.testimonial3.name'),
      role: t('testimonials.testimonial3.role'),
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80',
      content: t('testimonials.testimonial3.content'),
      rating: 5,
    },
  ];

  return (
    <section className="py-28 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-24">
          <h2 className="text-2xl sm:text-section-title text-wellness-gray mb-8">
            {t('testimonials.title')}
          </h2>
          <p className="text-sm sm:text-section-body text-wellness-gray/60 max-w-2xl mx-auto">
            {t('testimonials.subtitle')}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          {testimonials.map((testimonial, index) => (
            <NeumorphicCard key={index} padding="lg" className="bg-wellness-extra-light-beige flex flex-col h-full hover:shadow-soft-lg transition-shadow duration-300">
              <div className="flex items-center space-x-1 mb-6">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-wellness-gray/20 text-wellness-gray/40" strokeWidth={1.5} />
                ))}
              </div>

              <p className="text-xs sm:text-section-body text-wellness-gray/80 mb-10 flex-grow">
                "{testimonial.content}"
              </p>

              <div className="flex items-center space-x-5">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-14 h-14 rounded-wellness object-cover shadow-soft border border-wellness-gray/5"
                />
                <div>
                  <div className="text-xs sm:text-body-sm font-semibold text-wellness-gray">{testimonial.name}</div>
                  <div className="text-[0.625rem] sm:text-caption text-wellness-gray/60">{testimonial.role}</div>
                </div>
              </div>
            </NeumorphicCard>
          ))}
        </div>
      </div>
    </section>
  );
}
