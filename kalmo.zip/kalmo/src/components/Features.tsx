import { NeumorphicCard } from './NeumorphicCard';
import { Shield, Video, Bell, Lock, Zap, Brain } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export function Features() {
  const { t } = useTranslation();
  
  const features = [
    {
      icon: Brain,
      title: t('features.aiPowered.title'),
      description: t('features.aiPowered.description'),
    },
    {
      icon: Video,
      title: t('features.monitoring.title'),
      description: t('features.monitoring.description'),
    },
    {
      icon: Bell,
      title: t('features.instantAlerts.title'),
      description: t('features.instantAlerts.description'),
    },
    {
      icon: Lock,
      title: t('features.privacyFirst.title'),
      description: t('features.privacyFirst.description'),
    },
    {
      icon: Zap,
      title: t('features.easySetup.title'),
      description: t('features.easySetup.description'),
    },
    {
      icon: Shield,
      title: t('features.medicalGrade.title'),
      description: t('features.medicalGrade.description'),
    },
  ];

  return (
    <section id="features" className="py-28 bg-white/50 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-24">
          <h2 className="text-2xl sm:text-section-title text-wellness-gray mb-8">
            {t('features.title')}
          </h2>
          <p className="text-sm sm:text-body-lg text-wellness-gray/60 max-w-2xl mx-auto">
            {t('features.subtitle')}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <NeumorphicCard key={index} padding="lg" className="bg-wellness-extra-light-beige hover:shadow-soft-lg transition-shadow duration-300">
                <div className="space-y-6">
                  <div className="w-14 h-14 rounded-wellness bg-gradient-to-br from-wellness-beige to-wellness-yellow shadow-soft flex items-center justify-center border border-wellness-gray/5">
                    <Icon className="w-7 h-7 text-wellness-gray" strokeWidth={1.5} />
                  </div>
                  <h3 className="text-sm sm:text-card-title text-wellness-gray">{feature.title}</h3>
                  <p className="text-xs sm:text-card-body text-wellness-gray/70">{feature.description}</p>
                </div>
              </NeumorphicCard>
            );
          })}
        </div>
      </div>
    </section>
  );
}
