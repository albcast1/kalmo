import { NeumorphicCard } from './NeumorphicCard';
import { Activity, Bell, Video, Moon } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useQuery } from '@tanstack/react-query';
import { useTRPC } from '~/trpc/react';

export function Benefits() {
  const { t } = useTranslation();
  const trpc = useTRPC();
  const imageUrlQuery = useQuery(trpc.getBenefitsImageUrl.queryOptions());
  
  const benefits = [
    {
      icon: Activity,
      title: t('benefits.fallDetection.title'),
      description: t('benefits.fallDetection.description'),
    },
    {
      icon: Bell,
      title: t('benefits.realTimeAlerts.title'),
      description: t('benefits.realTimeAlerts.description'),
    },
    {
      icon: Video,
      title: t('benefits.highDefinition.title'),
      description: t('benefits.highDefinition.description'),
    },
    {
      icon: Moon,
      title: t('benefits.nightVision.title'),
      description: t('benefits.nightVision.description'),
    },
  ];

  return (
    <section id="benefits" className="py-16 md:py-20 bg-gradient-beige-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section heading */}
        <div className="text-center mb-20">
          <h2 className="text-2xl sm:text-section-title text-wellness-gray mb-4 whitespace-pre-line">
            {t('benefits.title')}
          </h2>
        </div>

        {/* Two-column layout: image on left, benefits on right */}
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left column - Image */}
          <div className="rounded-wellness-lg overflow-hidden">
            {imageUrlQuery.data?.imageUrl ? (
              <img 
                src={imageUrlQuery.data.imageUrl}
                alt="Video surveillance cameras for fall detection"
                className="w-full h-auto object-cover transform scale-110 hover:scale-115 transition-transform duration-500"
              />
            ) : (
              <div className="w-full aspect-video bg-wellness-gray/10 animate-pulse flex items-center justify-center">
                <Video className="w-12 h-12 text-wellness-gray/30" />
              </div>
            )}
          </div>

          {/* Right column - Benefits */}
          <div className="space-y-6">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <NeumorphicCard key={index} padding="sm" shadow="none" className="bg-transparent hover:shadow-soft-xl transition-all duration-300 border-0">
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 rounded-wellness bg-wellness-blue/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-wellness-gray" strokeWidth={2} />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-sm sm:text-card-title text-wellness-gray mb-1">
                        {benefit.title}
                      </h3>
                      <p className="text-xs sm:text-card-body text-wellness-gray/70">
                        {benefit.description}
                      </p>
                    </div>
                  </div>
                </NeumorphicCard>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
