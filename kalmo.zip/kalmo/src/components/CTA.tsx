import { NeumorphicButton } from './NeumorphicButton';
import { useTranslation } from 'react-i18next';

export function CTA() {
  const { t } = useTranslation();
  
  return (
    <section className="py-28 bg-white relative overflow-hidden">
      {/* Subtle geometric accent */}
      <div className="absolute top-10 left-10 w-96 h-96 bg-wellness-extra-light-beige/30 rounded-full blur-3xl"></div>
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-wellness-extra-light-beige/40 rounded-full blur-3xl"></div>
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
        <h2 className="text-2xl sm:text-section-title text-wellness-gray mb-8">
          {t('cta.title')}
        </h2>
        <p className="text-sm sm:text-section-body text-wellness-gray/70 mb-14 max-w-2xl mx-auto">
          {t('cta.description')}
        </p>

        <div className="flex flex-row gap-5 justify-center items-center mb-12">
          <a href="#pricing">
            <NeumorphicButton variant="primary" size="md">
              {t('cta.ctaSubscribe')}
            </NeumorphicButton>
          </a>
          <a href="#benefits">
            <NeumorphicButton variant="secondary" size="md">
              {t('cta.ctaBuyNow')}
            </NeumorphicButton>
          </a>
        </div>

        <p className="text-xs sm:text-caption text-wellness-gray/60">
          {t('cta.guarantee')}
        </p>
      </div>
    </section>
  );
}
